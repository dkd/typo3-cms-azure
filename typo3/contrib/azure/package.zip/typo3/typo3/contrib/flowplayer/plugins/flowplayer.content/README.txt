Version history:

3.2.8
-----
- Added a drop shadow, can be enabled by setting dropShadow: true in the configuration

3.2.0
-----
- Added new added onBeforeCss() and onBeforeAnimate() callback functions, that are now part of the Styleable interface.

3.1.0
-----
Changes:
- added public get and set functions for accessing the content view style property
- supports outlining the text with a black outline (using the flash glow filter), this is enabled using
  textDecoration: 'outline'

3.0.1
-----
- dispatches the LOAD event when initialized (needed for flowplayer 3.0.2 compatibility)

3.0.0
-----
- 3.0.0-final release

beta3
-----
- does not change the text format initialized by the player

beta2
-----
- no changes, just practicing plugin versioning

beta1
-----
- First public beta release
