Please *DO NOT* reference/use the jQuery-libraries in this folder from your
own extensions. They are used throughout the TYPO3 CMS core but may be renamed
or removed without further notice in later TYPO3-versions.

We plan to provide and promote a central API for using jQuery (also in various
versions) in one of the next releases.
